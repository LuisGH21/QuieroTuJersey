#!/usr/bin/env bash
set -euo pipefail

destino=/srv/quierotujersey
unidad=/etc/systemd/system/quierotujersey.service
sitio=/etc/nginx/sites-available/quierotujersey
enlace=/etc/nginx/sites-enabled/quierotujersey
predeterminado=/etc/nginx/sites-enabled/default
respaldo=/etc/nginx/default.antes-de-quierotujersey
archivos=(app/app.py app/database.py requirements.txt
          deploy/quierotujersey.service deploy/quierotujersey.nginx.conf)

fallar() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

uso() {
    printf '%s\n' 'Uso: bash scripts/desplegar.sh --plan [REF]' \
        '     bash scripts/desplegar.sh --install [REF]' \
        '     bash scripts/desplegar.sh --verify'
}

comprobar_servicios() {
    local servicio
    for servicio in postgresql quierotujersey nginx; do
        systemctl is-enabled --quiet "$servicio" || fallar "$servicio no está habilitado."
        systemctl is-active --quiet "$servicio" || fallar "$servicio no está activo."
        printf '%s: habilitado y activo\n' "$servicio"
    done
    pg_isready -h localhost -p 5432
}

comprobar_http() {
    python3 - "$1" "$2" <<'PY'
import json
import re
import sys
import time
from urllib.request import ProxyHandler, build_opener

url, servidor = sys.argv[1:]
http = build_opener(ProxyHandler({}))
for intento in range(1, 11):
    try:
        with http.open(url + "/estado", timeout=3) as respuesta:
            estado = json.load(respuesta)
            cabecera = respuesta.headers.get("Server", "").lower()
            if (respuesta.status != 200 or cabecera.split("/", 1)[0] != servidor
                    or not isinstance(estado, dict)
                    or estado.get("aplicacion") != "QuieroTuJersey"
                    or estado.get("base_de_datos") != "conectada"):
                raise ValueError("/estado no confirma el servidor esperado y la base conectada")
        if servidor == "nginx":
            with http.open(url + "/jerseys", timeout=3) as respuesta:
                html = respuesta.read().decode("utf-8")
                fichas = len(re.findall(r'<div class="jersey">', html))
                if (respuesta.status != 200
                        or respuesta.headers.get("Server", "").lower().split("/", 1)[0] != servidor
                        or "QuieroTuJersey" not in html or fichas == 0):
                    raise ValueError("/jerseys no contiene un catálogo servido por NGINX")
                print(f"{servidor} /jerseys: HTTP 200, fichas={fichas}")
        print(f"{servidor} /estado: HTTP 200, PostgreSQL conectado")
        break
    except (OSError, ValueError) as error:
        if intento == 10:
            sys.exit(f"{servidor}: falló la comprobación HTTP: {error}")
        time.sleep(1)
PY
}

case "${1:-}" in
    --help|-h) uso; exit 0 ;;
    --verify)
        [[ $# == 1 ]] || fallar '--verify no recibe argumentos.'
        comprobar_servicios
        comprobar_http http://127.0.0.1:8000 gunicorn
        comprobar_http http://127.0.0.1 nginx
        exit 0 ;;
    --plan|--install) [[ $# -le 2 ]] || fallar 'Indica como máximo una referencia Git.' ;;
    *) uso >&2; exit 2 ;;
esac

repo=$(git -C "$(dirname -- "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)
ref=${2:-HEAD}
commit=$(git -C "$repo" rev-parse --verify --end-of-options "$ref^{commit}") || fallar 'Referencia Git inválida.'
for archivo in "${archivos[@]}"; do
    [[ $(git -C "$repo" cat-file -t "$commit:$archivo") == blob ]] || fallar "Falta $archivo en $commit."
done
printf 'Commit: %s\nDestino: %s\nUnidad: %s\nSitio: %s\n' "$commit" "$destino" "$unidad" "$sitio"
[[ $1 == --install ]] || exit 0

[[ $EUID != 0 ]] || fallar 'Ejecuta como el usuario del clon; el script invoca sudo cuando lo necesita.'
[[ $(uname -s) == Linux && -d /run/systemd/system ]] || fallar 'Se requiere Linux con systemd activo.'
command -v apt-get >/dev/null || fallar 'Se requiere Ubuntu con apt-get.'
[[ -f "$repo/.env" && ! -L "$repo/.env" && -O "$repo/.env" ]] || fallar 'El .env debe ser un archivo de tu usuario.'
[[ $(stat -c %a "$repo/.env") == 600 ]] || fallar 'Usa permisos 600 para el .env.'
systemctl is-active --quiet postgresql || fallar 'Prepara el servicio PostgreSQL primero.'
pg_isready -h localhost -p 5432 || fallar 'Prepara PostgreSQL en localhost:5432 primero.'

paso='comprobaciones administrativas'
trap 'printf "Falló el despliegue durante: %s. Revisa ese paso antes de volver a ejecutar --install.\n" "$paso" >&2' ERR
sudo -v </dev/tty
for ruta in "$destino" "$unidad" "$sitio" "$enlace" "$respaldo"; do
    if sudo test -e "$ruta" || sudo test -L "$ruta"; then
        fallar "Ya existe $ruta. Para comprobar un despliegue existente usa --verify."
    fi
done

paso='paquetes del servidor'
sudo apt-get update
sudo apt-get install -y nginx python3-venv
if sudo test -e "$predeterminado" || sudo test -L "$predeterminado"; then
    if ! sudo test -L "$predeterminado" ||
        [[ $(sudo readlink -f -- "$predeterminado") != /etc/nginx/sites-available/default ]]; then
        fallar 'El sitio default de NGINX no referencia el archivo predeterminado del paquete.'
    fi
fi
sudo nginx -t

paso='usuario y copia de la aplicación'
if ! id quierotujersey >/dev/null 2>&1; then
    sudo useradd --system --user-group --home-dir "$destino" --shell /usr/sbin/nologin quierotujersey
fi
sudo install -d -m 750 -o quierotujersey -g quierotujersey "$destino"
git -C "$repo" archive "$commit" | sudo -u quierotujersey tar -x -C "$destino"
sudo install -m 600 -o quierotujersey -g quierotujersey "$repo/.env" "$destino/.env"

paso='entorno virtual y conexión a PostgreSQL'
sudo -u quierotujersey -H python3 -m venv "$destino/.venv"
python="$destino/.venv/bin/python"
sudo -u quierotujersey -H "$python" -m pip install --no-cache-dir -r "$destino/requirements.txt"
sudo -u quierotujersey -H "$python" - "$destino" <<'PY'
from pathlib import Path
from secrets import token_hex
import sys

from dotenv import dotenv_values, set_key

destino = Path(sys.argv[1])
env = destino / ".env"
config = dotenv_values(env)
for clave, esperado in {"DB_HOST": "localhost", "DB_PORT": "5432",
                        "DB_NAME": "quierotujersey", "DB_USER": "quierotujersey_app"}.items():
    if config.get(clave) != esperado:
        sys.exit(f"Configura {clave} en el .env de origen según la guía.")
if not config.get("DB_PASSWORD") or config["DB_PASSWORD"] == "cambia_esta_contrasena":
    sys.exit("Configura DB_PASSWORD en el .env de origen.")
if config.get("FLASK_SECRET_KEY") in (None, "", "genera_una_clave_aleatoria"):
    set_key(env, "FLASK_SECRET_KEY", token_hex(32))
set_key(env, "FLASK_DEBUG", "0")
env.chmod(0o600)

sys.path.insert(0, str(destino / "app"))
import psycopg
from database import obtener_conexion

try:
    with obtener_conexion() as conexion:
        existe_catalogo = conexion.execute("SELECT EXISTS (SELECT FROM public.v_catalogo)").fetchone()[0]
except psycopg.Error:
    sys.exit("No se pudo consultar v_catalogo con la configuración de la aplicación.")
if not existe_catalogo:
    sys.exit("v_catalogo no tiene jerseys activos.")
print("PostgreSQL: conexión y lectura del catálogo verificadas.")
PY

paso='unidad systemd de Gunicorn'
git -C "$repo" show "$commit:deploy/quierotujersey.service" | sudo tee "$unidad" >/dev/null
sudo chmod 644 "$unidad"
sudo systemctl daemon-reload
sudo systemctl enable --now quierotujersey
comprobar_http http://127.0.0.1:8000 gunicorn

paso='sitio de NGINX'
git -C "$repo" show "$commit:deploy/quierotujersey.nginx.conf" | sudo tee "$sitio" >/dev/null
sudo chmod 644 "$sitio"
sudo ln -s "$sitio" "$enlace"
movido=0
if sudo test -L "$predeterminado"; then
    sudo mv -- "$predeterminado" "$respaldo"
    movido=1
fi
if ! sudo nginx -t; then
    sudo unlink "$enlace"
    if (( movido )); then
        sudo mv -- "$respaldo" "$predeterminado"
    fi
    fallar 'NGINX rechazó el sitio. Se restauró la selección anterior de sitios.'
fi
sudo systemctl enable --now nginx
sudo systemctl reload nginx

paso='verificación final'
comprobar_servicios
comprobar_http http://127.0.0.1 nginx
