#!/usr/bin/env bash
# =============================================================
# QuieroTuJersey - respaldo completo de la base de datos
#
# Uso:
#   scripts/respaldo_bd.sh [nombre_bd] [carpeta_destino]
#
#   nombre_bd        Base a respaldar (por defecto: quierotujersey)
#   carpeta_destino  Carpeta existente donde se guarda el respaldo
#                    (por defecto: carpeta database/ del proyecto)
#
# Ejemplos:
#   Desarrollo (macOS o WSL, usuario con acceso a la BD):
#     ./scripts/respaldo_bd.sh
#
#   Servidor Ubuntu (como root; el volcado lo hace el usuario postgres):
#     sudo install -d -m 700 /var/backups/quierotujersey
#     sudo /srv/quierotujersey/scripts/respaldo_bd.sh quierotujersey /var/backups/quierotujersey
#
# Genera: respaldo_<bd>_<AAAAMMDD_HHMMSS>.sql con permisos 600.
# Si pg_dump falla o el volcado esta incompleto, no deja archivo.
# Compatible con Linux y macOS (bash 3.2 o superior).
# =============================================================
set -euo pipefail

BD="${1:-quierotujersey}"
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
DESTINO="${2:-${RAIZ}/database}"

error() {
    echo "ERROR: $*" >&2
    exit 1
}

# Permisos restrictivos para todo archivo creado por este script (600)
umask 077

command -v pg_dump >/dev/null 2>&1 || error "pg_dump no esta instalado o no esta en el PATH."
[ -d "$DESTINO" ] || error "La carpeta de destino no existe: $DESTINO"
[ -w "$DESTINO" ] || error "No se puede escribir en la carpeta de destino: $DESTINO"

DESTINO="$(cd "$DESTINO" && pwd)"
ARCHIVO="${DESTINO}/respaldo_${BD}_$(date +%Y%m%d_%H%M%S).sql"

[ -e "$ARCHIVO" ] && error "Ya existe un respaldo con ese nombre: $ARCHIVO"

# El volcado se escribe primero en un archivo temporal de la misma
# carpeta y solo se renombra al nombre final si termino correctamente.
TEMPORAL="$(mktemp "${DESTINO}/.respaldo_${BD}.XXXXXX")"
trap 'rm -f "$TEMPORAL"' EXIT

if [ "$(id -u)" -eq 0 ]; then
    # Como root no existe un rol de PostgreSQL equivalente: el volcado
    # lo hace el usuario del sistema postgres y root escribe el archivo.
    command -v runuser >/dev/null 2>&1 || error "Se requiere runuser para ejecutar como root."
    runuser -u postgres -- pg_dump --dbname="$BD" --no-owner --format=plain > "$TEMPORAL" \
        || error "pg_dump fallo; no se genero ningun respaldo."
else
    pg_dump --dbname="$BD" --no-owner --format=plain > "$TEMPORAL" \
        || error "pg_dump fallo; no se genero ningun respaldo."
fi

# Comprobacion de integridad: pg_dump escribe esta linea al terminar
grep -q -- "-- PostgreSQL database dump complete" "$TEMPORAL" \
    || error "El volcado esta incompleto; no se genero ningun respaldo."

mv "$TEMPORAL" "$ARCHIVO"
trap - EXIT

echo "Respaldo generado: $ARCHIVO"
ls -l "$ARCHIVO"
