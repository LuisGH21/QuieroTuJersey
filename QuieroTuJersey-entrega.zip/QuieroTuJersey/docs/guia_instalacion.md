# Guía de instalación y despliegue — QuieroTuJersey

Guía reproducible para instalar QuieroTuJersey en un equipo **x86_64 genérico**
con **Ubuntu Server 26.04 LTS** instalado de forma nativa (bare metal), clonando
el proyecto directamente desde GitHub.

Convenciones:

- `[PC]` se ejecuta en la computadora de trabajo (Windows, macOS o Linux).
- `[SRV]` se ejecuta en el servidor Ubuntu, directamente o por SSH.
- `[FOTO]` indica una evidencia para el reporte. Durante el instalador no hay
  capturas de pantalla: se toman fotos con el celular.
- Los textos entre `< >` se sustituyen por valores propios, por ejemplo
  `<IP_DEL_SERVIDOR>` o `<usuario_admin>`.

Valores fijos del proyecto (deben coincidir con `deploy/`):

| Elemento | Valor |
|---|---|
| Directorio de la aplicación | `/srv/quierotujersey` |
| Usuario del sistema que ejecuta la app | `quierotujersey` (sin shell ni contraseña) |
| Base de datos / rol de la app | `quierotujersey` / `quierotujersey_app` |
| Gunicorn | `127.0.0.1:8000`, servicio `quierotujersey` |
| NGINX | Puerto 80, proxy hacia Gunicorn |
| Respaldos | `/var/backups/quierotujersey` (solo root) |

---

## 0. Alcance y advertencias

- Esta guía es para el **despliegue definitivo bare metal**. Los pasos pueden
  ensayarse antes en WSL2, pero **las evidencias del proyecto solo valen si se
  obtienen en el equipo bare metal** (en WSL `systemd-detect-virt` responde
  `wsl`, no `none`).
- **La instalación usando el disco completo borra todos los datos del equipo
  destino.** Antes de empezar, respaldar la información o usar un equipo cuyo
  contenido se pueda perder.
- No se modifica el equipo de trabajo: solo se usa para grabar la USB y, si se
  desea, para conectarse por SSH al servidor.

---

## 1. Requisitos del equipo destino

| Requisito | Mínimo | Recomendado |
|---|---|---|
| Procesador | x86_64 (Intel o AMD de 64 bits) | — |
| RAM | 1.5 GB | 4 GB o más |
| Disco | 25 GB | 50 GB o más |
| USB para el instalador | 4 GB | 8 GB o más (se borra completa) |
| Red | Wi-Fi | Cable Ethernet |

No sirven equipos ARM (por ejemplo Mac con Apple Silicon o Chromebook ARM),
máquinas virtuales, contenedores ni WSL.

Anotar fabricante y modelo del equipo destino para el reporte.

---

## 2. Preparar la USB de instalación `[PC]`

1. Descargar `ubuntu-26.04.1-live-server-amd64.iso` y el archivo `SHA256SUMS`
   desde https://ubuntu.com/download/server.
2. Verificar la integridad de la ISO. Los dos valores deben ser idénticos
   (Windows muestra el hash en mayúsculas; la comparación no distingue
   mayúsculas de minúsculas).

   **Windows (PowerShell), en la carpeta de descargas:**

   ```powershell
   Get-FileHash .\ubuntu-26.04.1-live-server-amd64.iso -Algorithm SHA256
   ```

   ```powershell
   Select-String -Path .\SHA256SUMS -Pattern "live-server-amd64"
   ```

   **macOS o Linux:**

   ```bash
   shasum -a 256 ubuntu-26.04.1-live-server-amd64.iso
   ```

   ```bash
   grep live-server-amd64 SHA256SUMS
   ```

3. Grabar la USB.

   **Windows: Rufus.** Elegir la USB en *Dispositivo* (comprobar el tamaño:
   se borra por completo), seleccionar la ISO, esquema de partición **GPT**,
   sistema destino **UEFI** y *Empezar*. Si Rufus pregunta el modo de escritura,
   elegir **modo imagen ISO**.

   **macOS (alternativa):** identificar la USB con `diskutil list external`,
   desmontarla con `diskutil unmountDisk /dev/diskN` y grabar con
   `sudo dd if=ubuntu-26.04.1-live-server-amd64.iso of=/dev/rdiskN bs=4m`
   (sustituir `N` por el número correcto; `Ctrl + T` muestra el avance).
   Alternativa gráfica en cualquier sistema: balenaEtcher.

---

## 3. Preparar el equipo destino

1. Conectar la USB y, si existe, el cable de red.
2. Encender y abrir el menú de arranque. La tecla depende del fabricante
   (comúnmente `F12`, `F11`, `F9`, `F8` o `Esc`); se indica en la pantalla de
   inicio o en el manual del equipo. Elegir la USB en modo **UEFI**.
3. **Secure Boot** puede quedar activado: Ubuntu lo soporta.
4. **Almacenamiento Intel VMD / RST:** en algunos equipos Intel el instalador no
   detecta el disco NVMe porque está en modo VMD/RST. Si en la pantalla de
   almacenamiento no aparece ningún disco, **detener la instalación**: cambiar
   ese modo en la BIOS solo debe hacerse en un equipo que se va a borrar por
   completo, porque puede impedir que arranque el sistema existente.
5. **Equipos sin Ethernet:** el instalador permite configurar Wi-Fi en la
   pantalla de red (nombre y contraseña de la red a la mano). Alternativa: un
   adaptador USB-Ethernet.
6. **Arranque dual (opcional, no recomendado):** solo si el equipo debe
   conservar otro sistema. En Windows desactivar el *Inicio rápido*, comprobar
   si hay BitLocker y guardar su clave de recuperación, y liberar al menos
   50 GB con *Administración de discos → Reducir volumen*.

---

## 4. Instalador de Ubuntu Server `[FOTO en cada pantalla]`

| Pantalla | Selección |
|---|---|
| Idioma | Español |
| Teclado | El del equipo (por ejemplo *Spanish (Latin American)*) |
| Tipo de instalación | Ubuntu Server (no la versión minimizada) |
| Red | La interfaz cableada o Wi-Fi obtiene IP por DHCP. **Anotar la IP.** |
| Proxy | Vacío, salvo que la red lo requiera |
| Mirror | El sugerido |
| Almacenamiento | Ver la tabla siguiente |
| Perfil | Nombre, `<nombre_servidor>`, `<usuario_admin>` y contraseña propios |
| Ubuntu Pro | Omitir |
| SSH | **Marcar "Install OpenSSH server"** |
| Snaps adicionales | Ninguno |

### Almacenamiento

Opción recomendada: **Custom storage layout** sobre el disco completo, para
documentar el esquema. **Esta opción borra todo el disco seleccionado.**

| Partición | Tamaño | Formato | Punto de montaje | Propósito |
|---|---|---|---|---|
| EFI | 1 GB | FAT32 | `/boot/efi` | Arranque UEFI |
| boot | 2 GB | ext4 | `/boot` | Kernels e initramfs |
| swap | 4 GB | swap | — | Memoria de intercambio |
| raíz | 30 GB o más | ext4 | `/` | Sistema, PostgreSQL y aplicación |
| home | resto | ext4 | `/home` | Datos de usuarios |

En arranque dual se usa solo el espacio libre y se **reutiliza la partición EFI
existente sin formatearla**.

Al terminar, retirar la USB cuando el instalador lo indique y reiniciar.

---

## 5. Primer arranque y evidencias de hardware nativo `[SRV]`

Iniciar sesión con `<usuario_admin>`. Desde aquí se puede trabajar por SSH desde
la computadora de trabajo:

```bash
ssh <usuario_admin>@<IP_DEL_SERVIDOR>
```

Crear la carpeta de evidencias:

```bash
mkdir -p ~/evidencias
```

Comprobar que **no** es una máquina virtual (debe responder `none`):

```bash
systemd-detect-virt | tee ~/evidencias/01_virtualizacion.txt
```

Fabricante y modelo físico del equipo:

```bash
sudo dmidecode -t system | tee ~/evidencias/02_dmidecode.txt
```

Procesador, memoria, discos y red:

```bash
lscpu | tee ~/evidencias/03_lscpu.txt
```

```bash
free -h | tee ~/evidencias/04_memoria.txt
```

```bash
lsblk -f | tee ~/evidencias/05_particiones.txt
```

```bash
df -hT | tee ~/evidencias/06_espacio.txt
```

```bash
ip -br a | tee ~/evidencias/07_red.txt
```

```bash
hostnamectl | tee ~/evidencias/08_hostnamectl.txt
```

```bash
cat /etc/os-release | tee ~/evidencias/09_os_release.txt
```

`[FOTO]` o captura por SSH de cada salida.

---

## 6. Actualización y zona horaria del sistema `[SRV]`

```bash
sudo apt update
```

```bash
sudo apt full-upgrade -y
```

Zona horaria del sistema (registros y `journalctl`). La base de datos ya fija
`America/Mexico_City` por su cuenta en `00_roles.sql`:

```bash
sudo timedatectl set-timezone America/Mexico_City
```

```bash
timedatectl
```

```bash
sudo reboot
```

---

## 7. Firewall (UFW) `[SRV]`

Permitir SSH **antes** de activar el firewall para no perder la conexión:

```bash
sudo ufw allow OpenSSH
```

```bash
sudo ufw enable
```

```bash
sudo ufw status verbose
```

El puerto 80 se abre en la sección 15, después de instalar NGINX.

---

## 8. Paquetes del servidor `[SRV]`

```bash
sudo apt install -y postgresql nginx python3-venv git
```

Verificar versiones y servicios:

```bash
psql --version
```

```bash
nginx -v
```

```bash
python3 --version
```

```bash
git --version
```

```bash
systemctl status postgresql --no-pager
```

```bash
systemctl status nginx --no-pager
```

---

## 9. Usuario de sistema y clonación desde GitHub `[SRV]`

Usuario sin shell ni contraseña que será dueño del código y ejecutará Gunicorn:

```bash
sudo useradd --system --home-dir /srv/quierotujersey --shell /usr/sbin/nologin quierotujersey
```

Directorio de la aplicación, propiedad de ese usuario:

```bash
sudo install -d -o quierotujersey -g quierotujersey -m 755 /srv/quierotujersey
```

Clonar el repositorio **como el usuario `quierotujersey`**. Así todos los
archivos tienen un mismo propietario y Git no reporta conflictos de propiedad:

```bash
sudo -u quierotujersey -H git clone https://github.com/LuisGH21/QuieroTuJersey.git /srv/quierotujersey
```

### Desplegar una versión validada

Se despliega la versión que ya se probó (en WSL2 o en otro entorno), no
necesariamente lo último de `main`. Se usa una etiqueta (por ejemplo `v1.0.0`)
o el hash de un commit:

```bash
sudo -u quierotujersey -H git -C /srv/quierotujersey checkout <VERSION>
```

Registrar la versión desplegada (evidencia):

```bash
sudo -u quierotujersey -H git -C /srv/quierotujersey log --oneline -1
```

Para comandos de Git en `/srv/quierotujersey` usar siempre
`sudo -u quierotujersey -H git -C /srv/quierotujersey ...`; ejecutarlos como
otro usuario provoca el error *dubious ownership*.

Si el repositorio se vuelve privado, la clonación requerirá un token de acceso
personal o una llave SSH de solo lectura (*deploy key*).

---

## 10. Base de datos `[SRV]`

Los scripts se leen desde el repositorio clonado. En este punto
`/srv/quierotujersey` aún tiene permisos 755, así que el usuario `postgres`
puede leerlos (los permisos se restringen en la sección 13).

```bash
cd /srv/quierotujersey/database
```

```bash
sudo -u postgres psql -v ON_ERROR_STOP=1 -d postgres -f 00_roles.sql
```

```bash
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f 01_base.sql
```

```bash
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f 02_pedidos.sql
```

```bash
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f 03_vistas_funciones.sql
```

Asignar la contraseña del rol de la aplicación (se pide sin mostrarla; se usará
en `.env`):

```bash
sudo -u postgres psql -c "\password quierotujersey_app"
```

Verificar:

```bash
sudo -u postgres psql -d quierotujersey -c '\dt'
```

```bash
sudo -u postgres psql -d quierotujersey -c '\dv'
```

```bash
sudo -u postgres psql -d quierotujersey -c 'SHOW timezone;'
```

Debe mostrar `America/Mexico_City`.

```bash
cd /srv/quierotujersey
```

---

## 11. Entorno virtual y dependencias `[SRV]`

```bash
sudo -u quierotujersey -H python3 -m venv /srv/quierotujersey/.venv
```

```bash
sudo -u quierotujersey -H /srv/quierotujersey/.venv/bin/pip install --no-cache-dir -r /srv/quierotujersey/requirements.txt
```

```bash
sudo -u quierotujersey -H /srv/quierotujersey/.venv/bin/gunicorn --version
```

---

## 12. Variables de entorno (`.env`) `[SRV]`

Crear `.env` a partir de la plantilla, como el usuario de la aplicación y con
permisos `600` desde el inicio:

```bash
sudo -u quierotujersey -H cp /srv/quierotujersey/.env.example /srv/quierotujersey/.env
```

```bash
sudo chmod 600 /srv/quierotujersey/.env
```

Generar la clave secreta de Flask (copiar el resultado):

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Generar el hash de la contraseña de administrador. Pide la contraseña sin
mostrarla e imprime el hash (copiar el resultado):

```bash
sudo -u quierotujersey -H /srv/quierotujersey/.venv/bin/python -c 'import getpass; from werkzeug.security import generate_password_hash as g; print(g(getpass.getpass("Contraseña admin: ")))'
```

Editar el archivo (al editarlo con `sudo` se conservan propietario y permisos):

```bash
sudo nano /srv/quierotujersey/.env
```

Contenido en el servidor:

```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=quierotujersey
DB_USER=quierotujersey_app
DB_PASSWORD='<contraseña de la sección 10>'

FLASK_SECRET_KEY=<clave generada>
FLASK_DEBUG=0
ADMIN_PASSWORD_HASH='<hash generado>'
```

Reglas de formato:

- Una variable por línea, sin espacios alrededor de `=`.
- `DB_PASSWORD` y `ADMIN_PASSWORD_HASH` **entre comillas simples**: el hash
  contiene `$` y las contraseñas pueden contener `#` o espacios. Los valores no
  deben contener comillas simples.
- `FLASK_DEBUG=0` siempre en el servidor.
- La aplicación lee `.env` con python-dotenv; el servicio de systemd no lo
  carga, por lo que no se usa `EnvironmentFile`.

---

## 13. Propietario y permisos `[SRV]`

```bash
sudo chown -R quierotujersey:quierotujersey /srv/quierotujersey
```

```bash
sudo chmod 750 /srv/quierotujersey
```

```bash
sudo chmod 600 /srv/quierotujersey/.env
```

```bash
sudo ls -la /srv/quierotujersey
```

Resultado esperado: todo pertenece a `quierotujersey`, el directorio tiene
`drwxr-x---` y `.env` tiene `-rw-------`. NGINX no necesita leer estos archivos
porque solo reenvía las peticiones a Gunicorn.

---

## 14. Servicio de Gunicorn (systemd) `[SRV]`

```bash
sudo cp /srv/quierotujersey/deploy/quierotujersey.service /etc/systemd/system/
```

```bash
sudo systemctl daemon-reload
```

```bash
sudo systemctl enable --now quierotujersey
```

```bash
systemctl status quierotujersey --no-pager
```

```bash
curl -s http://127.0.0.1:8000/estado
```

Si el servicio falla, revisar el registro:

```bash
sudo journalctl -u quierotujersey -n 50 --no-pager
```

---

## 15. NGINX `[SRV]`

```bash
sudo cp /srv/quierotujersey/deploy/quierotujersey.nginx.conf /etc/nginx/sites-available/quierotujersey
```

```bash
sudo ln -s /etc/nginx/sites-available/quierotujersey /etc/nginx/sites-enabled/quierotujersey
```

```bash
sudo rm /etc/nginx/sites-enabled/default
```

```bash
sudo nginx -t
```

```bash
sudo systemctl reload nginx
```

```bash
sudo ufw allow 'Nginx HTTP'
```

---

## 16. Verificación final `[SRV]` y `[PC]`

```bash
curl -s http://localhost/estado
```

Debe mostrar `"base_de_datos": "conectada"` y un sistema Linux.

```bash
systemctl is-enabled nginx postgresql quierotujersey
```

```bash
sudo ss -tlnp
```

Resultado esperado: NGINX en `0.0.0.0:80`, Gunicorn en `127.0.0.1:8000` y
PostgreSQL en `127.0.0.1:5432` (no expuestos a la red).

```bash
sudo ufw status verbose
```

Desde la computadora de trabajo, abrir `http://<IP_DEL_SERVIDOR>/` y recorrer
todas las vistas, incluido un pedido completo y el panel de administración.
Comprobar que la fecha del pedido coincide con la hora local. `[FOTO]` de cada
vista.

Prueba de arranque automático:

```bash
sudo reboot
```

Al volver, sin iniciar nada a mano:

```bash
systemctl is-active nginx postgresql quierotujersey
```

```bash
curl -s http://localhost/estado
```

---

## 17. Respaldo de la base de datos `[SRV]`

Carpeta de respaldos accesible solo para root:

```bash
sudo install -d -m 700 /var/backups/quierotujersey
```

Generar el respaldo (el script usa el usuario `postgres` para el volcado, crea el
archivo con permisos `600` y no deja archivos incompletos si algo falla):

```bash
sudo /srv/quierotujersey/scripts/respaldo_bd.sh quierotujersey /var/backups/quierotujersey
```

```bash
sudo ls -l /var/backups/quierotujersey
```

Para el entregable, copiar el respaldo a la computadora de trabajo. Primero
dejar una copia legible solo por `<usuario_admin>`:

```bash
sudo install -m 600 -o <usuario_admin> /var/backups/quierotujersey/<ARCHIVO>.sql ~/respaldo_quierotujersey.sql
```

`[PC]` descargarla (PowerShell, macOS o Linux):

```bash
scp <usuario_admin>@<IP_DEL_SERVIDOR>:respaldo_quierotujersey.sql .
```

`[SRV]` borrar la copia temporal:

```bash
rm ~/respaldo_quierotujersey.sql
```

---

## 18. Actualizar a una nueva versión validada `[SRV]`

```bash
sudo -u quierotujersey -H git -C /srv/quierotujersey fetch --tags origin
```

```bash
sudo -u quierotujersey -H git -C /srv/quierotujersey checkout <VERSION>
```

```bash
sudo -u quierotujersey -H /srv/quierotujersey/.venv/bin/pip install --no-cache-dir -r /srv/quierotujersey/requirements.txt
```

```bash
sudo systemctl restart quierotujersey
```

```bash
sudo -u quierotujersey -H git -C /srv/quierotujersey log --oneline -1
```

```bash
curl -s http://localhost/estado
```

Si la nueva versión incluye cambios en `deploy/`, volver a copiar el archivo
correspondiente (secciones 14 o 15). Los scripts de `database/` crean la base
desde cero y **no** se vuelven a ejecutar sobre una base existente: hacer un
respaldo antes de cualquier cambio en la base de datos.

---

## Lista de evidencias para el reporte (solo equipo bare metal)

| # | Evidencia | Sección |
|---|---|---|
| 1 | Fotos del instalador (idioma, red, almacenamiento, perfil, SSH) | 4 |
| 2 | `systemd-detect-virt` = `none` | 5 |
| 3 | `dmidecode` con fabricante y modelo reales | 5 |
| 4 | `lscpu`, `free -h`, `lsblk -f`, `df -hT` | 5 |
| 5 | `ip -br a` y `hostnamectl` | 5 |
| 6 | `ufw status verbose` | 7 y 16 |
| 7 | `systemctl status` de postgresql, nginx y quierotujersey | 8 y 14 |
| 8 | Versión desplegada (`git log --oneline -1`) | 9 |
| 9 | `SHOW timezone;` y tablas/vistas de la BD | 10 |
| 10 | `ls -la /srv/quierotujersey` (propietario y permisos) | 13 |
| 11 | `nginx -t` exitoso | 15 |
| 12 | `curl /estado` mostrando Linux y PostgreSQL | 16 |
| 13 | `ss -tlnp` con los puertos esperados | 16 |
| 14 | Vistas del sitio desde otro equipo de la red | 16 |
| 15 | Servicios activos después de reiniciar | 16 |
| 16 | Respaldo generado con permisos `600` | 17 |
