# Despliegue automatizado de QuieroTuJersey

El script automatiza la instalación de la aplicación en `/srv/quierotujersey`,
su entorno de Python, la unidad de Gunicorn y el sitio de NGINX. Elige una
revisión de Git y verifica que Flask se pueda conectar a PostgreSQL antes de
habilitar el sitio.

1. En Ubuntu con systemd, usa un clon de trabajo fuera de `/srv`, por ejemplo
   `~/QuieroTuJersey`. Conserva `/srv/quierotujersey` libre en una instalación
   nueva. Si ya seguiste el procedimiento manual, pasa a la verificación.
2. Prepara PostgreSQL y los datos de QuieroTuJersey siguiendo la sección 10 de
   [la guía](guia_instalacion.md). El script necesita la base y el rol existentes
   y PostgreSQL activo y habilitado en `localhost:5432`.
3. En la raíz del clon, prepara `.env` según la sección 12 de la guía. Déjalo
   con permisos `600` y con las credenciales del rol. El instalador genera
   `FLASK_SECRET_KEY` si falta y fija `FLASK_DEBUG=0` en la copia de despliegue.
   Si vas a usar el panel, incluye el `ADMIN_PASSWORD_HASH` generado con
   Werkzeug. El archivo de origen queda disponible para usos posteriores.

Desde la raíz del clon, ejecuta:

```bash
bash scripts/desplegar.sh --plan HEAD
bash scripts/desplegar.sh --install HEAD
```

`--plan` resuelve la revisión y comprueba que incluya los archivos necesarios,
sin requerir privilegios. Puedes sustituir `HEAD` por una etiqueta o un hash
verificado. `--install` requiere `sudo` interactivo; el script lo invoca según
lo necesita. Conserva el enlace predeterminado de NGINX en
`/etc/nginx/default.antes-de-quierotujersey` cuando corresponda.

En WSL2, usa estas comprobaciones como pruebas de desarrollo. En el equipo
físico, sigue además la guía para firewall, evidencias y prueba de reinicio.

Para revisar una instalación manual o automatizada sin modificarla:

```bash
bash scripts/desplegar.sh --verify
```

La verificación comprueba que PostgreSQL, Gunicorn y NGINX estén activos y
habilitados. Consulta `/estado` por Gunicorn y por NGINX, y verifica que
`/jerseys` muestre fichas. Puede reintentar unos segundos mientras se activa
el sitio después de una recarga. Para el catálogo inicial, se esperan seis fichas.

El modo de instalación se detiene si detecta archivos del despliegue anterior.
Si una instalación se interrumpe, revisa el paso reportado y el estado con
`--verify` antes de corregirla. El script no actualiza despliegues existentes
ni reinicializa PostgreSQL.

## Estado de validación

En WSL2 se ejecutaron `bash -n scripts/desplegar.sh`, `--plan 7b0b70c` y
`--verify` contra el despliegue manual. `/estado` respondió HTTP 200 por
Gunicorn y NGINX, con PostgreSQL conectado, y `/jerseys` mostró seis fichas.
También se restauró un respaldo en una base separada y se comparó el
contenido de las seis tablas con el origen.

Queda pendiente ejecutar `--install` de principio a fin en un entorno limpio.
