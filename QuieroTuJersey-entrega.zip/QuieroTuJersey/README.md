# QuieroTuJersey

Proyecto final de Unix: tienda en línea de jerseys de la Liga MX desplegada
en Ubuntu Server instalado de forma nativa (bare metal), con NGINX como proxy
inverso, Gunicorn como servidor de aplicaciones, Flask y PostgreSQL.

## Arquitectura

```
Navegador -> NGINX (:80) -> Gunicorn (127.0.0.1:8000) -> Flask -> PostgreSQL (:5432)
```

NGINX, Gunicorn (servicio `quierotujersey`) y PostgreSQL se ejecutan como
servicios de systemd.

## Estructura

```
app/                  Aplicación Flask (app.py, database.py, templates/)
database/             Scripts SQL en orden de ejecución
  00_roles.sql        Rol quierotujersey_app, base quierotujersey y zona horaria
  01_base.sql         Equipos, jerseys e inventario con datos iniciales
  02_pedidos.sql      Clientes, pedidos y detalle de pedido
  03_vistas_funciones.sql  Vistas y funciones PL/pgSQL
deploy/               Configuración de despliegue
  quierotujersey.service      Servicio systemd de Gunicorn
  quierotujersey.nginx.conf   Sitio de NGINX
docs/guia_instalacion.md      Guía de instalación en Ubuntu Server
scripts/respaldo_bd.sh        Respaldo completo de la BD con pg_dump
.env.example          Plantilla de variables de entorno (sin valores reales)
.gitattributes        Fuerza finales de línea LF en todos los archivos de texto
```

## Vistas

| Ruta | Descripción |
|---|---|
| `/` | Inicio |
| `/jerseys` | Catálogo |
| `/jerseys/<id>` | Detalle y selección de talla |
| `/carrito` | Carrito de compras |
| `/checkout` | Datos del cliente y confirmación |
| `/pedido/<id>` | Pedido registrado |
| `/admin/login` | Acceso de administrador |
| `/admin` | Lista de jerseys (alta, edición, baja) |
| `/admin/jerseys/nuevo`, `/admin/jerseys/<id>/editar` | Formulario de jersey |
| `/admin/pedidos` | Pedidos y cancelación |
| `/estado` | Estado del sistema y de la conexión a la BD (JSON) |

## Requisitos

| Componente | Versión de referencia |
|---|---|
| Sistema operativo | Ubuntu Server 26.04 LTS, x86_64 |
| Python | 3.14 (incluido en Ubuntu 26.04) |
| PostgreSQL | 18 (incluido en Ubuntu 26.04) |
| NGINX | Paquete de Ubuntu |
| Dependencias de Python | `requirements.txt` (Flask, Gunicorn, psycopg, python-dotenv) |

Gunicorn solo funciona en sistemas tipo Unix. En Windows el proyecto se
desarrolla y prueba dentro de WSL2 (ver más abajo).

## Despliegue en Ubuntu Server

El procedimiento completo y reproducible está en
[`docs/guia_instalacion.md`](docs/guia_instalacion.md): instalación del sistema,
clonación desde GitHub, base de datos, variables de entorno, systemd, NGINX,
firewall, verificación, respaldos y actualización a una versión validada.

## Crear la base de datos

En Ubuntu (o WSL), con el superusuario `postgres` y desde la raíz del proyecto:

```bash
sudo -u postgres psql -v ON_ERROR_STOP=1 -d postgres -f database/00_roles.sql
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f database/01_base.sql
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f database/02_pedidos.sql
sudo -u postgres psql -v ON_ERROR_STOP=1 -d quierotujersey -f database/03_vistas_funciones.sql
sudo -u postgres psql -c "\password quierotujersey_app"
```

En macOS con Homebrew el usuario actual es superusuario de PostgreSQL: se usan
los mismos comandos sin `sudo -u postgres`.

## Variables de entorno

Copiar `.env.example` como `.env` y llenar los valores. Reglas:

- Una variable por línea, en formato `NOMBRE=valor`, sin espacios alrededor de `=`.
- Valores con caracteres especiales (`$`, `#`, espacios) entre comillas simples,
  por ejemplo `ADMIN_PASSWORD_HASH='scrypt:...'`. El valor no debe contener
  comillas simples.
- La aplicación lee `.env` con python-dotenv al iniciar; systemd no lo lee.
- `.env` nunca se sube a Git y en el servidor debe tener permisos `600`.

Generar la clave secreta de Flask:

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Generar el hash de la contraseña de administrador (con el entorno virtual activo):

```bash
python -c 'import getpass; from werkzeug.security import generate_password_hash as g; print(g(getpass.getpass("Contraseña admin: ")))'
```

## Despliegue automatizado

La [guía del instalador](docs/despliegue_automatizado.md) explica cómo
preparar una instalación y comprobar un despliegue existente. En WSL2 se
validaron el plan y la verificación de servicios. La prueba automatizada
desde cero queda pendiente en un entorno limpio.

## Desarrollo y pruebas en WSL2

WSL2 se usa solo como entorno de desarrollo y pruebas. Las evidencias del
proyecto se generan exclusivamente en el equipo con Ubuntu Server bare metal.

- Clonar el repositorio dentro del sistema de archivos de Linux (por ejemplo
  `~/QuieroTuJersey`), no en `/mnt/c`, para evitar problemas de permisos,
  rendimiento y finales de línea.
- Un clon solo incluye cambios confirmados (commit).

Ejecutar en modo de desarrollo:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env    # y llenar los valores
python app/app.py
```

Abrir `http://127.0.0.1:5001/`.

Ejecutar con Gunicorn, como en el servidor:

```bash
gunicorn --chdir app --workers 3 --bind 127.0.0.1:8000 app:app
```

## Respaldo de la base de datos

```bash
./scripts/respaldo_bd.sh [nombre_bd] [carpeta_destino]
```

Genera `respaldo_<bd>_<AAAAMMDD_HHMMSS>.sql` con permisos `600`; si `pg_dump`
falla o el volcado queda incompleto, no deja ningún archivo. En el servidor se
ejecuta con `sudo` hacia `/var/backups/quierotujersey` (ver la guía).

## Finales de línea

`.gitattributes` obliga a que todos los archivos de texto se descarguen con LF
en cualquier sistema operativo. Los scripts, el servicio de systemd y la
configuración de NGINX fallan en Linux si contienen finales CRLF de Windows.
